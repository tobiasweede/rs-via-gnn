import numpy as np

def random_prediction_model(input_features):
  return np.random.rand()
